# See http://docs.chef.io/config_rb_knife.html for more information on knife configuration options

current_dir = File.dirname(__FILE__)
log_level                :info
log_location             STDOUT
node_name                "mani5a3"
client_key               "#{current_dir}/mani5a3.pem"
chef_server_url          "https://api.chef.io/organizations/chef_repo1"
cookbook_path            ["#{current_dir}/../cookbooks"]
